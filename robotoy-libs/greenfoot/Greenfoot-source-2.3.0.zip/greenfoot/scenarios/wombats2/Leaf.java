import greenfoot.*;  // imports Actor, World, Greenfoot, GreenfootImage

/**
 * Leaf - a class for representing leafs.
 *
 * @author Michael Kolling
 * @version 1.0.1
 */
public class Leaf extends Actor
{
    public Leaf()
    {
    }

    public void act()
    {
        //here you can create the behaviour of your object
    }

}
